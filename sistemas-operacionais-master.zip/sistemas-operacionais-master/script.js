// JAVASCRIPT NOVO

function openNav() {
  document.getElementById("myNav").style.width = "35%";
  document.getElementById("myNav").style.display = "block";
}

function closeNav() {
  document.getElementById("myNav").style.width = "0%";
  document.getElementById("myNav").style.display = "none";

}

// FINAL JAVASCRIPT NOVO